# object detection > blood-cell-v1
https://universe.roboflow.com/ayushs-workspace-vad8h/object-detection-4guhe

Provided by a Roboflow user
License: CC BY 4.0

